import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { ProfileView } from '../components/profile/ProfileView';
import { ProfileForm } from '../components/profile/ProfileForm';
import type { Partner } from '../types';
import toast from 'react-hot-toast';

export default function Profile() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [partner, setPartner] = useState<Partner | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    birthDate: '',
    anniversaryDate: '',
    interests: [] as string[],
    favoriteColors: [] as string[],
    clothingSize: '',
    shoeSize: '',
    jewelryPreferences: [] as string[],
  });

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    const fetchPartner = async () => {
      try {
        const { data, error } = await supabase
          .from('partners')
          .select('*')
          .eq('user_id', user.id)
          .single();

        if (error) throw error;
        setPartner(data);
        setFormData({
          name: data.name,
          birthDate: data.birth_date,
          anniversaryDate: data.anniversary_date || '',
          interests: data.interests,
          favoriteColors: data.favorite_colors,
          clothingSize: data.clothing_size,
          shoeSize: data.shoe_size,
          jewelryPreferences: data.jewelry_preferences,
        });
      } catch (error) {
        toast.error('Failed to load partner profile');
      }
    };

    fetchPartner();
  }, [user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { error } = await supabase
        .from('partners')
        .update({
          name: formData.name,
          birth_date: formData.birthDate,
          anniversary_date: formData.anniversaryDate || null,
          interests: formData.interests,
          favorite_colors: formData.favoriteColors,
          clothing_size: formData.clothingSize,
          shoe_size: formData.shoeSize,
          jewelry_preferences: formData.jewelryPreferences,
        })
        .eq('user_id', user?.id);

      if (error) throw error;
      toast.success('Profile updated successfully!');
      setIsEditing(false);
    } catch (error) {
      toast.error('Failed to update profile');
    }
  };

  if (!partner) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center">
          <p className="text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Partner Profile</h1>
        <button
          onClick={() => setIsEditing(!isEditing)}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-rose-600 hover:bg-rose-700"
        >
          {isEditing ? 'Cancel' : 'Edit Profile'}
        </button>
      </div>

      {isEditing ? (
        <ProfileForm
          formData={formData}
          onSubmit={handleSubmit}
          onChange={(data) => setFormData({ ...formData, ...data })}
        />
      ) : (
        <ProfileView partner={partner} />
      )}
    </div>
  );
}