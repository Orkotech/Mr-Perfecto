import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { UpcomingEvents } from '../components/dashboard/UpcomingEvents';
import { GiftSuggestions } from '../components/dashboard/GiftSuggestions';
import type { Partner, SpecialDate } from '../types';
import toast from 'react-hot-toast';

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [partner, setPartner] = useState<Partner | null>(null);
  const [events, setEvents] = useState<SpecialDate[]>([]);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    const fetchData = async () => {
      try {
        // Fetch partner data
        const { data: partnerData, error: partnerError } = await supabase
          .from('partners')
          .select('*')
          .eq('user_id', user.id)
          .single();

        if (partnerError) throw partnerError;
        setPartner(partnerData);

        // Fetch special dates
        const { data: eventsData, error: eventsError } = await supabase
          .from('special_dates')
          .select('*')
          .eq('user_id', user.id);

        if (eventsError) throw eventsError;
        setEvents(eventsData);
      } catch (error) {
        toast.error('Failed to load dashboard data');
      }
    };

    fetchData();
  }, [user, navigate]);

  if (!partner) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-gray-900">Welcome to Mr. Perfecto!</h2>
          <p className="mt-2 text-gray-600">Let's start by setting up your partner's profile.</p>
          <button
            onClick={() => navigate('/partner-setup')}
            className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-rose-600 hover:bg-rose-700"
          >
            Set Up Partner Profile
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">
        Welcome back, {user?.email}
      </h1>
      <div className="grid gap-8 grid-cols-1 lg:grid-cols-2">
        <UpcomingEvents events={events} />
        <GiftSuggestions partner={partner} />
      </div>
    </div>
  );
}