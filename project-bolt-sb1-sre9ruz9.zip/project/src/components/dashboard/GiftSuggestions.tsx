import React from 'react';
import { Gift } from 'lucide-react';
import type { Partner } from '../../types';

interface GiftSuggestionsProps {
  partner: Partner;
}

export function GiftSuggestions({ partner }: GiftSuggestionsProps) {
  const suggestions = generateGiftSuggestions(partner);

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-2xl font-semibold text-gray-900 mb-4">Gift Ideas</h2>
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
        {suggestions.map((suggestion, index) => (
          <div
            key={index}
            className="border rounded-lg p-4 hover:bg-rose-50 transition-colors"
          >
            <div className="flex items-center mb-2">
              <Gift className="h-5 w-5 text-rose-600 mr-2" />
              <h3 className="text-lg font-medium text-gray-900">{suggestion.title}</h3>
            </div>
            <p className="text-sm text-gray-600">{suggestion.description}</p>
            {suggestion.price && (
              <p className="mt-2 text-sm font-medium text-rose-600">{suggestion.price}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function generateGiftSuggestions(partner: Partner) {
  const suggestions = [];
  const interests = partner.interests || [];

  if (interests.includes('Reading')) {
    suggestions.push({
      title: 'Book Subscription Box',
      description: 'A curated selection of books based on her reading preferences',
      price: '$30-50/month',
    });
  }

  if (interests.includes('Spa & Wellness')) {
    suggestions.push({
      title: 'Spa Day Package',
      description: 'Full day of pampering with massage and treatments',
      price: '$150-300',
    });
  }

  // Add more suggestions based on interests...

  return suggestions;
}