export interface User {
  id: string;
  email: string;
  created_at: string;
}

export interface Partner {
  id: string;
  user_id: string;
  name: string;
  birth_date: string;
  anniversary_date: string | null;
  interests: string[];
  favorite_colors: string[];
  clothing_size: string;
  shoe_size: string;
  jewelry_preferences: string[];
  created_at: string;
}

export interface SpecialDate {
  id: string;
  user_id: string;
  partner_id: string;
  date: string;
  occasion: string;
  notes: string;
  created_at: string;
}